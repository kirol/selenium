package running;
import SimpleCalc.SimpleCalc;

public class Run {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int _number1 = 50;
		int _number2 = 20;
		
		//Testing static APIs
		System.out.println("Testing static APIs");
		int addRes = SimpleCalc.doAdd(_number1, _number2);
		int subtractRes = SimpleCalc.doSubtract(_number1, _number2);
		int multipleRes = SimpleCalc.doMultiple(_number1, _number2);
		int divideRes = SimpleCalc.doDivide(_number1, _number2);
		int moduloRes = SimpleCalc.doModulo(_number1, _number2);
		
		System.out.println("Adding: " + addRes);
		System.out.println("Subtracting: " + subtractRes);
		System.out.println("Multipling: " + multipleRes);
		System.out.println("Dividing: " + divideRes);
		System.out.println("Modulo: " + moduloRes);
		
		//Testing SimpleCalc instance and its methods
		System.out.println("Testing SimpleCalc instance and its methods");
		SimpleCalc _simpleCalc = new SimpleCalc(_number1, _number2);
		addRes = _simpleCalc.doAdd();
		subtractRes = _simpleCalc.doSubtract();
		multipleRes = _simpleCalc.doMultiple();
		divideRes = _simpleCalc.doDivide();
		moduloRes = _simpleCalc.doModulo();
		System.out.println("Adding: " + addRes);
		System.out.println("Subtracting: " + subtractRes);
		System.out.println("Multipling: " + multipleRes);
		System.out.println("Dividing: " + divideRes);
		System.out.println("Modulo: " + moduloRes);
	}
}
