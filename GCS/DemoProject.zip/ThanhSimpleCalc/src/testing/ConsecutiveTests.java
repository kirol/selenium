package testing;

import org.testng.annotations.Test;

import SimpleCalc.SimpleCalc;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;

public class ConsecutiveTests {
	private NumberElements _numberElement;
	
  @Test (parameters = { "number1", "number2", "addRes"})
  public void paramAddTest(int number1, int number2, int addRes) {
	  _numberElement.setNumber1(number1);
	  _numberElement.setNumber2(number2);
	  _numberElement.setRes(addRes);
	  
	  Assert.assertEquals(SimpleCalc.doAdd(number1, number2), _numberElement.getRes());
  }
    
  @DataProvider(name = "addTestData")
  public static Object[][] addTestData() {
     return new Object[][] { {new NumberElements(10, 20, 30)}, {new NumberElements(40, 50, 90)} };
  }
  
  @Test(dataProvider="addTestData")
  public void consecutiveAddTest(NumberElements myNumElm)
  {
	  _numberElement.setNumber1(myNumElm.getNumber1());
	  _numberElement.setNumber2(myNumElm.getNumber2());
	  _numberElement.setRes(myNumElm.getRes());
	  
	  Assert.assertEquals(SimpleCalc.doAdd(_numberElement.getNumber1(),_numberElement.getNumber2()),_numberElement.getRes());
  }
    
  
  	@BeforeMethod ()
	public void beforeTest() {
  		System.out.println("beforeTest");
		_numberElement = new NumberElements();
	}
	
	@AfterMethod  ()
	public void afterTest() {
		System.out.println("afterTest");
		_numberElement = null;
	}
}
