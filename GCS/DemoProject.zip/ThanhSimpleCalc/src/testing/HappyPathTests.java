package testing;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import SimpleCalc.SimpleCalc;

public class HappyPathTests {
	private enum CALC_METHOD {
		ADD, SUBTRACT, MULTIPLE, DIVIDE, MODULO
	}

	private NumberElements _numberElement;
	private SimpleCalc simpleCalc;

	@BeforeMethod (groups = {"STATICAPITEST", "LIBINSTANCETEST"})
	public void beforeTest() {
		_numberElement = new NumberElements();
	}
	
	@AfterMethod  (groups = {"STATICAPITEST", "LIBINSTANCETEST"})
	public void afterTest() {
		_numberElement = null;
	}

	//Test with SimpleCalc static APIs	
	@Test (groups="STATICAPITEST")
	public void testAddCalculator1() {
		_numberElement.setNumber1(20);
		_numberElement.setNumber2(40);
		int expectRes = 60;

		Assert.assertEquals(doTestByStaticAPI(CALC_METHOD.ADD, _numberElement.getNumber1(), _numberElement.getNumber2()), expectRes);
	}
	
	@Test (groups="STATICAPITEST")
	public void testSubtractCalculator1() {
		_numberElement.setNumber1(60);
		_numberElement.setNumber2(30);
		int expectRes = 30;

		Assert.assertEquals(doTestByStaticAPI(CALC_METHOD.SUBTRACT, _numberElement.getNumber1(), _numberElement.getNumber2()), expectRes);
	}
	
	@Test (groups="STATICAPITEST")
	public void testMultipleCalculator1() {
		_numberElement.setNumber1(60);
		_numberElement.setNumber2(30);
		int expectRes = 1800;

		Assert.assertEquals(doTestByStaticAPI(CALC_METHOD.MULTIPLE, _numberElement.getNumber1(), _numberElement.getNumber2()), expectRes);
	}
	
	@Test (groups="STATICAPITEST")
	public void testDivideCalculator1() {
		_numberElement.setNumber1(60);
		_numberElement.setNumber2(30);
		int expectRes = 2;

		Assert.assertEquals(doTestByStaticAPI(CALC_METHOD.DIVIDE, _numberElement.getNumber1(), _numberElement.getNumber2()), expectRes);
	}
	
	@Test (groups="STATICAPITEST")
	public void testModuloCalculator1() {
		_numberElement.setNumber1(70);
		_numberElement.setNumber2(30);
		int expectRes = 10;

		Assert.assertEquals(doTestByStaticAPI(CALC_METHOD.MODULO, _numberElement.getNumber1(), _numberElement.getNumber2()), expectRes);
	}

	//Test with SimpleCalc instance
	@Test (groups="LIBINSTANCETEST")
	public void testAddCalculator2() {
		_numberElement.setNumber1(20);
		_numberElement.setNumber2(40);
		int expectRes = 60;

		Assert.assertEquals(doTestByInstance(CALC_METHOD.ADD, _numberElement.getNumber1(), _numberElement.getNumber2()), expectRes);
	}
	
	@Test (groups="LIBINSTANCETEST")
	public void testSubtractCalculator2() {
		_numberElement.setNumber1(60);
		_numberElement.setNumber2(30);
		int expectRes = 30;

		Assert.assertEquals(doTestByInstance(CALC_METHOD.SUBTRACT, _numberElement.getNumber1(), _numberElement.getNumber2()), expectRes);
	}
	
	@Test (groups="LIBINSTANCETEST")
	public void testMultipleCalculator2() {
		_numberElement.setNumber1(60);
		_numberElement.setNumber2(30);
		int expectRes = 1800;

		Assert.assertEquals(doTestByInstance(CALC_METHOD.MULTIPLE, _numberElement.getNumber1(), _numberElement.getNumber2()), expectRes);
	}
	
	@Test (groups="LIBINSTANCETEST")
	public void testDivideCalculator2() {
		_numberElement.setNumber1(60);
		_numberElement.setNumber2(30);
		int expectRes = 2;

		Assert.assertEquals(doTestByInstance(CALC_METHOD.DIVIDE, _numberElement.getNumber1(), _numberElement.getNumber2()), expectRes);
	}
	
	@Test (groups="LIBINSTANCETEST")
	public void testModuloCalculator2() {
		_numberElement.setNumber1(70);
		_numberElement.setNumber2(30);
		int expectRes = 10;

		Assert.assertEquals(doTestByInstance(CALC_METHOD.MODULO, _numberElement.getNumber1(), _numberElement.getNumber2()), expectRes);
	}

	private int doTestByStaticAPI(CALC_METHOD method, int number1, int number2)
	{
	  switch (method)
	  {
		  case ADD:
			  _numberElement.setRes(SimpleCalc.doAdd(_numberElement.getNumber1(),_numberElement.getNumber2()));			  
			  break;
		  case SUBTRACT:
			  _numberElement.setRes(SimpleCalc.doSubtract(_numberElement.getNumber1(),_numberElement.getNumber2()));			  
			  break;
		  case MULTIPLE:
			  _numberElement.setRes(SimpleCalc.doMultiple(_numberElement.getNumber1(),_numberElement.getNumber2()));			  
			  break;
		  case DIVIDE:
			  _numberElement.setRes(SimpleCalc.doDivide(_numberElement.getNumber1(),_numberElement.getNumber2()));
			  break;
		  case MODULO:
			  _numberElement.setRes(SimpleCalc.doModulo(_numberElement.getNumber1(),_numberElement.getNumber2()));			  
	  }
	  
	  return _numberElement.getRes();
	}
	
	private int doTestByInstance(CALC_METHOD method, int _number1, int _number2)
	{
		simpleCalc = new SimpleCalc(_number1, _number2);
		switch (method)
		{
		  case ADD:
			  _numberElement.setRes(simpleCalc.doAdd());			  
			  break;
		  case SUBTRACT:
			  _numberElement.setRes(simpleCalc.doSubtract());			  
			  break;
		  case MULTIPLE:
			  _numberElement.setRes(simpleCalc.doMultiple());			  
			  break;
		  case DIVIDE:
			  _numberElement.setRes(simpleCalc.doDivide());
			  break;
		  case MODULO:
			  _numberElement.setRes(simpleCalc.doModulo());			  
		}
	  
	  return _numberElement.getRes();
	}
}
