package testing;

import org.testng.annotations.Test;

import SimpleCalc.SimpleCalc;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;

public class InvalidTests {
	NumberElements _numberElement;
	
  @Test (expectedExceptions=ArithmeticException.class)
  public void divideZeroTest() {
	  _numberElement.setNumber1(100);
	  _numberElement.setNumber2(0);
	  _numberElement.setRes(SimpleCalc.doDivide(_numberElement.getNumber1(),_numberElement.getNumber2()));	  	  
  }
  
  @Test (groups = "NaN", dependsOnMethods={ "divideZeroTest" })
  public void divideNaNTest() {
	  Double testVal = 100/Double.NaN;	  	  
  }
  
  @Test (groups = { "INFINITE" }, dependsOnMethods={"divideNaNTest"})
  public void dividePositiveInfiniteTest() {
	  Double testVal = 100/Double.POSITIVE_INFINITY;	  	  
  }
  
  @Test (groups = { "INFINITE" })
  public void divideNegativeInfiniteTest() {
	  Double testVal = 100/Double.NEGATIVE_INFINITY;	  	  
  }
  
  @Test (groups = "EXPONENT", dependsOnGroups = {"INFINITE"})
  public void divideMaxExponentTest() {
	  int testVal = 100/Double.MAX_EXPONENT;	  	  
  }
  
  @Test (groups = "EXPONENT", dependsOnGroups = {"INFINITE"})
  public void divideMinExponentTest() {
	  int testVal = 100/Double.MIN_EXPONENT;	  	  
  }
  
  @BeforeMethod
  public void beforeMethod() {
	  _numberElement = new NumberElements();
  }

  @AfterMethod
  public void afterMethod() {
	  _numberElement = null;
  }

}
