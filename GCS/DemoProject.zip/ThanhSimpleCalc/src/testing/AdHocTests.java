package testing;

import org.testng.annotations.Test;

import SimpleCalc.SimpleCalc;

import org.testng.annotations.BeforeMethod;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;

public class AdHocTests {
	private NumberElements _numberElement;
	
  @Test
  public void doAddMaxInteger() {
	  _numberElement.setNumber1(Integer.MAX_VALUE);
	  _numberElement.setNumber2(0);	  
	  _numberElement.setRes(SimpleCalc.doAdd(_numberElement.getNumber1(),_numberElement.getNumber2()));
	  
	  Assert.assertEquals(Integer.MAX_VALUE, _numberElement.getRes());
  }
  
  @Test (enabled = false)
  public void doAddMinInteger() {
	  _numberElement.setNumber1(Integer.MIN_VALUE);
	  _numberElement.setNumber2(0);	  
	  _numberElement.setRes(SimpleCalc.doSubtract(_numberElement.getNumber1(),_numberElement.getNumber2()));
	  
	  Assert.assertEquals(Integer.MIN_VALUE, _numberElement.getRes());
  }
  
  @BeforeMethod
  public void beforeMethod() {
	  _numberElement = new NumberElements();
  }

  @AfterMethod
  public void afterMethod() {
	  _numberElement = null;
  }

}
