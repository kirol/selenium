package testing;

public class NumberElements {
	private int number1, number2;
	private int res;
	public NumberElements()
	{
		number1 = 0;
		number2 = 0;
		res = 0;
	}
	
	public NumberElements(int _number1, int _number2, int _res)
	{
		number1 = _number1;
		number2 = _number2;
		res = _res;
	}

	
	public int getRes() {
		return res;
	}

	public void setRes(int res) {
		this.res = res;
	}

	public int getNumber1() {
		return number1;
	}
	
	public void setNumber1(int number1) {
		this.number1 = number1;
	}
	
	public int getNumber2() {
		return number2;
	}
	
	public void setNumber2(int number2) {
		this.number2 = number2;
	}
}
