package SimpleCalc;


/**
 * A Java library to do simple calculation for 2 numbers 
 * @author Thanh Tran 
 * @version 1.0
 */	
public class SimpleCalc {
	private int _number1 = 0;
	private int _number2 = 0;
	
	/**
	 * Constructor to create a SimpleCalc instance with 2 numbers
	 * @param number1 an integer number 1 
	 * @param number2 an integer number 2
	 */	
	public SimpleCalc(int number1, int number2)
	{
		_number1 = number1;
		_number2 = number2;		
	}
	
	/**
	 * API to do adding with 2 numbers of SimpleCalc instance
	 * @return  Result of number 1 plus number 2 
	 */	
	public int doAdd()
	{
		return _number1 + _number2;
	}
	
	/**
	 * API to do subtracting with 2 numbers of SimpleCalc instance
	 * @return  Result of number 1 subtracting number 2 
	 */	
	public int doSubtract()
	{
		return _number1 - _number2;
	}
	
	/**
	 * API to do multiplying with 2 numbers of SimpleCalc instance
	 * @return  Result of number 1 multiplying with number 2 
	 */	
	public int doMultiple()
	{
		return _number1 * _number2;
	}
	
	/**
	 * API to do dividing with 2 numbers of SimpleCalc instance and only get the <b>INTEGER RESULT</b>
	 * @return  Result of number 1 dividing number 2
	 */	
	public int doDivide()
	{
		return _number1 / _number2;
	}
	
	/**
	 * API to do dividing with 2 numbers of SimpleCalc instance and only get the <b>REMAINDER</b>
	 * @return  Result of number 1 dividing number 2
	 */	
	public int doModulo()
	{
		return _number1 % _number2;
	}
	
	/**
	 * Static API to plus 2 numbers
	 * @param number1 an integer number 1 
	 * @param number2 an integer number 2
	 * @return Result of number 1 plus number 2 
	 */	
	public static int doAdd(int number1, int number2)
	{	
		return number1 + number2;
	}
	
	/**
	 * Static API to minus 2 numbers
	 * @param number1 an integer number 1 
	 * @param number2 an integer number 2
	 * @return Result of number 1 minus number 2 
	 */	
	public static int doSubtract(int number1, int number2)
	{	
		return number1 - number2;
	}
	
	/**
	 * Static API to multiple 2 numbers
	 * @param number1 an integer number 1 
	 * @param number2 an integer number 2
	 * @return Result of number 1 multiple with number 2 
	 */	
	public static int doMultiple(int number1, int number2)
	{	
		return number1 * number2;
	}
	
	/**
	 * Static API to divide 2 numbers and only get the <b>INTEGER RESULT</b>
	 * @param number1 an integer number 1 
	 * @param number2 an integer number 2
	 * @return Result of number 1 divide number 2  
	 */	
	public static int doDivide(int number1, int number2)
	{			
		return number1 / number2;
	}
	
	/**
	 * Static API to divide 2 numbers and only get the <b>REMAINDER</b>
	 * @param number1 an integer number 1 
	 * @param number2 an integer number 2
	 * @return Result of number 1 divide number 2  
	 */	
	public static int doModulo(int number1, int number2)
	{			
		return number1 % number2;
	}
}
